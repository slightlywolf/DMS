docker stop /angular-docker

docker rm /angular-docker