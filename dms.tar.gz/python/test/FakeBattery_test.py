class FakeBattery_test():
    pass