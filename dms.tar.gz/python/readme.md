The backend is Comprised of A flask server and python files which support interaction between
hardware and software.

The flask server acts as a REST api from which the front end (angular) can recieve data from
or POST data to, to allow 